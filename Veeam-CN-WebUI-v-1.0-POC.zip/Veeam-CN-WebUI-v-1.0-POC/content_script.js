// Veeam Enterprise Manager UI CN Language Pack
// first version 

window.addEventListener('load',walk(document.body));
var observer = new MutationObserver(function(mutations) {
	mutations.forEach(function(mutation) {
		walk(document.body);
	});    
});
 
// Notify me of everything!
var observerConfig = {
	attributes: true, 
	childList: true, 
	characterData: true 
};
 
// Node, config
// In this case we'll listen to all changes to body and child nodes
var targetNode = document.body;
observer.observe(targetNode, observerConfig);


function walk(node) 
{
	var ignore = { "STYLE":0, "SCRIPT":0, "NOSCRIPT":0, "IFRAME":0, "OBJECT":0 }
	// I stole this function from here:
	// http://is.gd/mwZp7E
	
	var child, next;
	
if (node.nodeName.toLowerCase() == 'input' || node.nodeName.toLowerCase() == 'textarea' || (node.classList && node.classList.contains('ace_editor'))) { return; }

	if (node.tagName in ignore) return;
	
	switch ( node.nodeType )  
	{
		case 1:  // Element
		case 9:  // Document
		case 11: // Document fragment
			child = node.firstChild;
			while ( child ) 
			{
				next = child.nextSibling;
				walk(child);
				child = next;
			}
			break;

		case 3: // Text node
			handleText(node);
			break;
	}
}

function handleText(textNode) 
{

	var v = textNode.nodeValue;

// the dictionar as following.

v = v.replace(/\bSelect virtual machines to process\b/igm, "选择要处理的虚拟机");
v = v.replace(/\bYour trial license will expire on\b /igm, "您的测试许可即将在此日到期");
v = v.replace(/\bDon't wait! Purchase a production license today\b /igm, "不要等待！今日就购买生产许可");
v = v.replace(/\bCreated by\b/igm, "生成日期");
v = v.replace(/\bChoose guest OS processing options available for running VMs\b/igm, "选择可用于运行VM的Guest虚拟机操作系统处理选项");
v = v.replace(/\bEnable application-aware image-processing\b/igm, "启用应用程序感知镜像处理");
v = v.replace(/\bRun the job automatically\b/igm, "自动运行作业");
v = v.replace(/\bDaily at this time\b/igm, "相同时刻每日一次");
v = v.replace(/\bMonthly at\b/igm, "每月一次");
v = v.replace(/\bAll changes will be lost. Do you want to proceed?\b/igm, "所有更改都将丢失，你想继续吗？");
v = v.replace(/\bSelect VM to view details\b/igm, "选择VM以查看详细信息");
v = v.replace(/\bSelf-Service Backup Portal For\b/igm, "自助备份门户网站");
v = v.replace(/\bWait before each attempt for\b/igm, "在每次尝试之前等待");
v = v.replace(/\bTerminate job if it gets out of allowed backup window\b/igm, "如果作业超出允许的备份窗口，则终止作业");
v = v.replace(/\bLast 24 hours\b/igm, "过去24小时");
v = v.replace(/\bLast 7 days\b/igm, "过去7天");
v = v.replace(/\bSpecify the job name, description and retention policy\b/igm, "指定作业名称，描述和保留策略");
v = v.replace(/\bJob name\b/igm, "工作名称");
v = v.replace(/\bRetention policy\b/igm, "保留政策");
v = v.replace(/\bRestore points to keep on disk\b/igm, "还原点以保留在磁盘上");
v = v.replace(/\bClose Wizard\b/igm, "关闭向导");
v = v.replace(/\bVirtual Machines\b/igm, "虚拟机");
v = v.replace(/\bAdd Objects\b/igm, "添加对象");
v = v.replace(/\bJob Schedule\b/igm, "工作时间表");
v = v.replace(/\bBackup window\b/igm, "备份窗口");
v = v.replace(/\bSelf-service backup portal\b/igm, "自助备份门户");
v = v.replace(/\bhas been created successfully.\b/igm, "已成功创建");
v = v.replace(/\bInstance license support is in progress\b/igm, "实例许可证支持正在进行中");
v = v.replace(/\bAverage speed\b/igm, "平均速度");
v = v.replace(/\bBackup Storage\b/igm, "备份存储");
v = v.replace(/\bType in\b/igm, "输入");
v = v.replace(/\bRestore Point\b/igm, "还原点");
v = v.replace(/\bDatabase to restore:\b/igm, "要恢复的数据库：");
v = v.replace(/\bPoint in time\b/igm, "时间点");
v = v.replace(/\bRestore to\b/igm, "恢复到");
v = v.replace(/\bLatest Run\b/igm, "最新的运行");
v = v.replace(/\bNext Run\b/igm, "下次运行");
v = v.replace(/\bFailover Plan\b/igm, "故障转移计划");
v = v.replace(/\bQuick Backup\b/igm, "快速备份");
v = v.replace(/\bLast Success\b/igm, "最后的成功");
v = v.replace(/\bPick from List\b/igm, "从列表中选择");
v = v.replace(/\bAdd to\b/igm, "添加");
v = v.replace(/\bBackup servers\b/igm, "备份服务器");
v = v.replace(/\bProcessing speed\b/igm, "处理速度");
v = v.replace(/\bSource size\b/igm, "来源大小");
v = v.replace(/\bFull backups\b/igm, "完整备份");
v = v.replace(/\bRestore points\b/igm, "还原点");
v = v.replace(/\bTotal job runs\b/igm, "总工作量");
v = v.replace(/\bSucceeded jobs\b/igm, "成功的工作");
v = v.replace(/\bManagement server\b/igm, "管理服务器");
v = v.replace(/\bNever started\b/igm, "从未开始");
v = v.replace(/\bVirtual machine\b/igm, "虚拟机");
v = v.replace(/\bNo Filter\b/igm, "没有过滤器");
v = v.replace(/\bApplication-Aware Processing Options\b/igm, "应用程序感知处理选项");
v = v.replace(/\bVeeam Backup Enterprise Manager\b/igm, "Veeam Backup企业管理器");
v = v.replace(/\bWelcome\b/igm, "欢迎");
v = v.replace(/\bPlease log in\b/igm, "请登录");
v = v.replace(/\bUsername\b/igm, "用户名");
v = v.replace(/\bPassword\b/igm, "密码");
v = v.replace(/\bRemember me\b/igm, "记住账号");
v = v.replace(/\bLogin\b/igm, "登录");
v = v.replace(/\bLoading, please stand by\b/igm, "正在加载，请等待...");
v = v.replace(/\bLoading\b/igm, "载入中");
v = v.replace(/\bCreate Backup Job\b/igm, "创建备份作业");
v = v.replace(/\bJob Settings\b/igm, "工作设置");
v = v.replace(/\bDescription\b/igm, "描述");
v = v.replace(/\bNext\b/igm, "下一个");
v = v.replace(/\bCancel\b/igm, "取消");
v = v.replace(/\bYes\b/igm, "是");
v = v.replace(/\bNo\b/igm, "没有");
v = v.replace(/\bAdd\b/igm, "增加");
v = v.replace(/\bRemove\b/igm, "去掉");
v = v.replace(/\bExclusions\b/igm, "排除");
v = v.replace(/\bUp\b/igm, "向上");
v = v.replace(/\bDown\b/igm, "下");
v = v.replace(/\bName\b/igm, "名称");
v = v.replace(/\bType\b/igm, "类型");
v = v.replace(/\bGuest Processing\b/igm, "来宾系统处理");
v = v.replace(/\bEnable guest file system indexing\b/igm, "启用客户机文件系统索引");
v = v.replace(/\bGuest OS credentials\b/igm, "客户操作系统凭据");
v = v.replace(/\bCredentials\b/igm, "安全凭据");
v = v.replace(/\bCustomize Credentials\b/igm, "自定义凭据");
v = v.replace(/\bSpecify the job scheduling options\b/igm, "指定作业计划选项");
v = v.replace(/\bAutomatic retry\b/igm, "自动重试");
v = v.replace(/\bRetry failed VM processing\b/igm, "重试失败的VM处理");
v = v.replace(/\bEmail notifications\b/igm, "邮件通知");
v = v.replace(/\bSpecify recipients and settings for th job status emails:\b/igm, "指定作业状态电子邮件的收件人和设置：");
v = v.replace(/\bEnable e-mail notifications\b/igm, "启用电子邮件通知");
v = v.replace(/\bRecipients\b/igm, "收件人");
v = v.replace(/\bSubject\b/igm, "主题");
v = v.replace(/\bNotify on success\b/igm, "通知成功");
v = v.replace(/\bNotify on warning\b/igm, "通知警告");
v = v.replace(/\bNotify on error\b/igm, "出错时通知");
v = v.replace(/\bSuppress notifications until the last retry\b/igm, "在最后一次重试之前禁止通知");
v = v.replace(/\bBack\b/igm, "返回");
v = v.replace(/\bFinish\b/igm, "完成");
v = v.replace(/\bSaving\b/igm, "保存");
v = v.replace(/\bShow\b/igm, "展示");
v = v.replace(/\bAll\b/igm, "所有");
v = v.replace(/\bNone\b/igm, "没有");
v = v.replace(/\bThroughput\b/igm, "吞吐量");
v = v.replace(/\bJob\b/igm, "作业");
v = v.replace(/\bSuccess\b/igm, "成功");
v = v.replace(/\bExport\b/igm, "导出");
v = v.replace(/\bDelete\b/igm, "删除");
v = v.replace(/\bTotal\b/igm, "汇总");
v = v.replace(/\bpoints\b/igm, "还原点");
v = v.replace(/\bruns\b/igm, "运行");
v = v.replace(/\bSucceeded\b/igm, "成功");
v = v.replace(/\bSource\b/igm, "资源");
v = v.replace(/\bsize\b/igm, "大小");
v = v.replace(/\bVerification\b/igm, "验证");
v = v.replace(/\bServer\b/igm, "服务器");
v = v.replace(/\bProtected\b/igm, "受保护");
v = v.replace(/\bVMs\b/igm, "虚拟机");
v = v.replace(/\bMax duration\b/igm, "最长持续时间");
v = v.replace(/\bQuota\b/igm, "配额");
v = v.replace(/\bUsed\b/igm, "用过的");
v = v.replace(/\bCreate\b/igm, "创建");
v = v.replace(/\bLast\b/igm, "持续");
v = v.replace(/\bSearch\b/igm, "搜索");
v = v.replace(/\bOwner\b/igm, "所有者");
v = v.replace(/\bDatabase\b/igm, "数据库");
v = v.replace(/\bOriginal\b/igm, "原有的");
v = v.replace(/\bAlternative\b/igm, "替代");
v = v.replace(/\bThis\b/igm, "这个");
v = v.replace(/\bServer:\b/igm, "服务器：");
v = v.replace(/\bDashboard\b/igm, "仪表板");
v = v.replace(/\bReports\b/igm, "报告");
v = v.replace(/\bAll Servers\b/igm, "所有服务器");
v = v.replace(/\bBackup Server\b/igm, "备份服务器");
v = v.replace(/\bJobs\b/igm, "作业");
v = v.replace(/\bStart\b/igm, "开始");
v = v.replace(/\bStop\b/igm, "停止");
v = v.replace(/\bRetry\b/igm, "重试");
v = v.replace(/\bName\b/igm, "名称");
v = v.replace(/\bType\b/igm, "类型");
v = v.replace(/\bPlatform\b/igm, "平台");
v = v.replace(/\bDescription\b/igm, "描述");
v = v.replace(/\bCreated\b/igm, "创建");
v = v.replace(/\bMachines\b/igm, "主机");
v = v.replace(/\bMachine\b/igm, "主机");
v = v.replace(/\bRestore\b/igm, "恢复");
v = v.replace(/\bHistory\b/igm, "历史");
v = v.replace(/\bLocation\b/igm, "地点");
v = v.replace(/\bPath\b/igm, "路径");
v = v.replace(/\bFiles\b/igm, "文件");
v = v.replace(/\bDownload\b/igm, "下载");
v = v.replace(/\bItems\b/igm, "项目");
v = v.replace(/\bRequests\b/igm, "要求");
v = v.replace(/\bConfiguration\b/igm, "配置");
v = v.replace(/\bRefresh\b/igm, "刷新");
v = v.replace(/\bSummary\b/igm, "摘要");
v = v.replace(/\bJobs\b/igm, "工作");
v = v.replace(/\bMachines\b/igm, "主机");
v = v.replace(/\bTemplates\b/igm, "模板");
v = v.replace(/\bData\b/igm, "数据");
v = v.replace(/\bWarning\b/igm, "警告");
v = v.replace(/\bError\b/igm, "错误");
v = v.replace(/\bStatus\b/igm, "状态");
v = v.replace(/\bBackups\b/igm, "备份");
v = v.replace(/\bBackup servers\b/igm, "备份服务器");
v = v.replace(/\bLicense\b/igm, "许可");
v = v.replace(/\bReload\b/igm, "刷新");
v = v.replace(/\bTags\b/igm, "标签");
v = v.replace(/\band\b/igm, "和");
v = v.replace(/\bEverything\b/igm, "一切");
v = v.replace(/\bCategory\b/igm, "类别");
v = v.replace(/\bStarting\b/igm, "开始");
v = v.replace(/\bWorking\b/igm, "工作");
v = v.replace(/\bEdit\b/igm, "编辑");
v = v.replace(/\bActive Full\b/igm, "积极充分");
v = v.replace(/\bDisable\b/igm, "禁用");
v = v.replace(/\bObject\b/igm, "对象");
v = v.replace(/\bIn progress\b/igm, "进行中");
v = v.replace(/\bPerformance\b/igm, "性能");
v = v.replace(/\bEnd Time\b/igm, "结束时间");
v = v.replace(/\bList\b/igm, "列表");
v = v.replace(/\bProcessing rate\b/igm, "处理率");
v = v.replace(/\bProcessed size\b/igm, "处理大小");
v = v.replace(/\bTotal time\b/igm, "总时间");
v = v.replace(/\bPerformance Rate\b/igm, "性能比率");
v = v.replace(/\bDetails\b/igm, "细节");
v = v.replace(/\bData Transferred\b/igm, "数据已转移");
v = v.replace(/\bFailed\b/igm, "失败");
v = v.replace(/\bLogout\b/igm, "退出");
v = v.replace(/\bCustomize Application\b/igm, "自定义应用程序");
v = v.replace(/\bTransaction logs\b/igm, "交易日志");
v = v.replace(/\bRequire success\b/igm, "请求成功");
v = v.replace(/\bExcludes\b/igm, "不包括");
v = v.replace(/\bGeneral\b/igm, "一般");
v = v.replace(/\bApplications\b/igm, "应用");
v = v.replace(/\bRequire successful application processing\b/igm, "请求成功应用正在处理");
v = v.replace(/\bIgnore application processing failures\b/igm, "忽略应用程序处理失败");
v = v.replace(/\bTransaction logs processing\b/igm, "事务日志处理");
v = v.replace(/\btimes\b/igm, "次");
v = v.replace(/\bminutes\b/igm, "分钟");
v = v.replace(/\bMail\b/igm, "邮件");
v = v.replace(/\bCalendar\b/igm, "日历");
v = v.replace(/\bContacts\b/igm, "联系人");
v = v.replace(/\bDuration\b/igm,"所用时间");
v = v.replace(/\bDate\b/igm,"日期");
v = v.replace(/\bState\b/igm,"状态");
v = v.replace(/\bBackup\b/igm,"备份");
v = v.replace(/\bApprove\b/igm,"批准");
v = v.replace(/\bReject\b/igm,"拒绝");
v = v.replace(/\bProlong\b/igm,"延长");








	
	textNode.nodeValue = v;
}


