// Veeam Enterprise Manager UI CN Language Pack
// first version 

window.addEventListener('load',walk(document.body));
var observer = new MutationObserver(function(mutations) {
	mutations.forEach(function(mutation) {
		walk(document.body);
	});    
});
 
// Notify me of everything!
var observerConfig = {
	attributes: true, 
	childList: true, 
	characterData: true 
};
 
// Node, config
// In this case we'll listen to all changes to body and child nodes
var targetNode = document.body;
observer.observe(targetNode, observerConfig);


function walk(node) 
{
	var ignore = { "STYLE":0, "SCRIPT":0, "NOSCRIPT":0, "IFRAME":0, "OBJECT":0 }
	// I stole this function from here:
	// http://is.gd/mwZp7E
	
	var child, next;
	
if (node.nodeName.toLowerCase() == 'input' || node.nodeName.toLowerCase() == 'textarea' || (node.classList && node.classList.contains('ace_editor'))) { return; }

	if (node.tagName in ignore) return;
	
	switch ( node.nodeType )  
	{
		case 1:  // Element
		case 9:  // Document
		case 11: // Document fragment
			child = node.firstChild;
			while ( child ) 
			{
				next = child.nextSibling;
				walk(child);
				child = next;
			}
			break;

		case 3: // Text node
			handleText(node);
			break;
	}
}

function handleText(textNode) 
{

	var v = textNode.nodeValue;

// the dictionary as following.

v = v.replace(/\bSelect virtual machines to process\b/igm, "처리 할 가상 컴퓨터 선택");
v = v.replace(/\bCreated by\b/igm, "작성자 :");
v = v.replace(/\bChoose guest OS processing options available for running VMs\b/igm, "VM을 실행하는 데 사용할 수있는 게스트 OS 처리 옵션 선택");
v = v.replace(/\bEnable application-aware image-processing\b/igm, "응용 프로그램 인식 이미지 처리 사용");
v = v.replace(/\bRun the job automatically\b/igm, "자동으로 작업 실행");
v = v.replace(/\bDaily at this time\b/igm, "이 시간에 매일");
v = v.replace(/\bMonthly at\b/igm, "매월");
v = v.replace(/\bAll changes will be lost. Do you want to proceed?\b/igm, "모든 변경 사항이 손실됩니다. 진행 하시겠습니까?");
v = v.replace(/\bSelect VM to view details\b/igm, "세부 정보를 보려면 VM 선택");
v = v.replace(/\bSelf-Service Backup Portal For\b/igm, "셀프 서비스 백업 포털");
v = v.replace(/\bWait before each attempt for\b/igm, "시도 할 때까지 기다리십시오.");
v = v.replace(/\bTerminate job if it gets out of allowed backup window\b/igm, "허용 된 백업 창을 벗어나면 작업 종료");
v = v.replace(/\bLast 24 hours\b/igm, "지난 24 시간");
v = v.replace(/\bLast 7 days\b/igm, "최근 7 일");
v = v.replace(/\bSpecify the job name, description and retention policy\b/igm, "작업 이름, 설명 및 보존 정책 지정");
v = v.replace(/\bJob name\b/igm, "직업 이름");
v = v.replace(/\bRetention policy\b/igm, "보존 정책");
v = v.replace(/\bRestore points to keep on disk\b/igm, "디스크에 유지할 지점 복원");
v = v.replace(/\bClose Wizard\b/igm, "마법사 닫기");
v = v.replace(/\bVirtual Machines\b/igm, "가상 머신");
v = v.replace(/\bAdd Objects\b/igm, "객체 추가");
v = v.replace(/\bJob Schedule\b/igm, "작업 일정");
v = v.replace(/\bBackup window\b/igm, "백업 창");
v = v.replace(/\bSelf-service backup portal\b/igm, "셀프 서비스 백업 포털");
v = v.replace(/\bhas been created successfully.\b/igm, "이 (가) 성공적으로 생성되었습니다.");
v = v.replace(/\bInstance license support is in progress\b/igm, "인스턴스 라이센스 지원이 진행 중입니다.");
v = v.replace(/\bAverage speed\b/igm, "평균 속도");
v = v.replace(/\bBackup Storage\b/igm, "백업 저장소");
v = v.replace(/\bType in\b/igm, "입력");
v = v.replace(/\bRestore Point\b/igm, "복원 지점");
v = v.replace(/\bDatabase to restore:\b/igm, "복원 할 데이터베이스 :");
v = v.replace(/\bPoint in time\b/igm, "특정 시점");
v = v.replace(/\bRestore to\b/igm, "복원 대상");
v = v.replace(/\bLatest Run\b/igm, "최신 실행");
v = v.replace(/\bNext Run\b/igm, "다음 실행");
v = v.replace(/\bFailover Plan\b/igm, "장애 조치 계획");
v = v.replace(/\bQuick Backup\b/igm, "빠른 백업");
v = v.replace(/\bLast Success\b/igm, "마지막 성공");
v = v.replace(/\bPick from List\b/igm, "목록에서 선택");
v = v.replace(/\bAdd to\b/igm, "에 추가");
v = v.replace(/\bBackup servers\b/igm, "백업 서버");
v = v.replace(/\bProcessing speed\b/igm, "처리 속도");
v = v.replace(/\bSource size\b/igm, "원본 크기");
v = v.replace(/\bFull backups\b/igm, "전체 백업");
v = v.replace(/\bRestore points\b/igm, "복원 지점");
v = v.replace(/\bTotal job runs\b/igm, "총 작업 실행");
v = v.replace(/\bSucceeded jobs\b/igm, "성공한 일자리");
v = v.replace(/\bManagement server\b/igm, "관리 서버");
v = v.replace(/\bNever started\b/igm, "시작하지 않았습니다.");
v = v.replace(/\bVirtual machine\b/igm, "가상 기기");
v = v.replace(/\bNo Filter\b/igm, "필터 없음");
v = v.replace(/\bApplication-Aware Processing Options\b/igm, "응용 프로그램 인식 처리 옵션");
v = v.replace(/\bVeeam Backup Enterprise Manager\b/igm, "Veeam 백업 엔터프라이즈 관리자");
v = v.replace(/\bWelcome\b/igm, "환영");
v = v.replace(/\bPlease log in\b/igm, "로그인 해주세요");
v = v.replace(/\bUsername\b/igm, "사용자 이름");
v = v.replace(/\bPassword\b/igm, "암호");
v = v.replace(/\bRemember me\b/igm, "날 기억해");
v = v.replace(/\bLogin\b/igm, "로그인");
v = v.replace(/\bLoading, please stand by\b/igm, "로드 중입니다. 대기해야합니다.");
v = v.replace(/\bLoading\b/igm, "로드 중");
v = v.replace(/\bCreate Backup Job\b/igm, "백업 작업 생성");
v = v.replace(/\bJob Settings\b/igm, "작업 설정");
v = v.replace(/\bDescription\b/igm, "기술");
v = v.replace(/\bNext\b/igm, "다음 것");
v = v.replace(/\bCancel\b/igm, "취소");
v = v.replace(/\bYes\b/igm, "예");
v = v.replace(/\bNo\b/igm, "아니");
v = v.replace(/\bAdd\b/igm, "더하다");
v = v.replace(/\bRemove\b/igm, "풀다");
v = v.replace(/\bExclusions\b/igm, "제외");
v = v.replace(/\bUp\b/igm, "쪽으로");
v = v.replace(/\bDown\b/igm, "내려가는");
v = v.replace(/\bName\b/igm, "이름");
v = v.replace(/\bType\b/igm, "유형");
v = v.replace(/\bGuest Processing\b/igm, "게스트 프로세싱");
v = v.replace(/\bEnable guest file system indexing\b/igm, "게스트 파일 시스템 색인 생성 사용");
v = v.replace(/\bGuest OS credentials\b/igm, "게스트 OS 자격 증명");
v = v.replace(/\bCredentials\b/igm, "신임장");
v = v.replace(/\bCustomize Credentials\b/igm, "자격 증명 사용자 지정");
v = v.replace(/\bSpecify the job scheduling options\b/igm, "작업 스케줄링 옵션 지정");
v = v.replace(/\bAutomatic retry\b/igm, "자동 재시도");
v = v.replace(/\bRetry failed VM processing\b/igm, "VM 처리에 실패했습니다.");
v = v.replace(/\bEmail notifications\b/igm, "이메일 알림");
v = v.replace(/\bSpecify recipients and settings for th job status emails:\b/igm, "작업 상태 이메일의 수신자 및 설정 지정 :");
v = v.replace(/\bEnable e-mail notifications\b/igm, "전자 메일 알림 사용");
v = v.replace(/\bRecipients\b/igm, "수신자");
v = v.replace(/\bSubject\b/igm, "제목");
v = v.replace(/\bNotify on success\b/igm, "성공시 알림");
v = v.replace(/\bNotify on warning\b/igm, "경고시 알림");
v = v.replace(/\bNotify on error\b/igm, "오류시 알림");
v = v.replace(/\bSuppress notifications until the last retry\b/igm, "마지막 재시도 때까지 알림을 표시하지 않습니다.");
v = v.replace(/\bBack\b/igm, "뒤로");
v = v.replace(/\bFinish\b/igm, "끝");
v = v.replace(/\bSaving\b/igm, "절약");
v = v.replace(/\bShow\b/igm, "보여 주다");
v = v.replace(/\bAll\b/igm, "모든");
v = v.replace(/\bNone\b/igm, "없음");
v = v.replace(/\bThroughput\b/igm, "처리량");
v = v.replace(/\bJob\b/igm, "일");
v = v.replace(/\bSuccess\b/igm, "성공");
v = v.replace(/\bExport\b/igm, "수출");
v = v.replace(/\bDelete\b/igm, "지우다");
v = v.replace(/\bTotal\b/igm, "합계");
v = v.replace(/\bpoints\b/igm, "전철기");
v = v.replace(/\bruns\b/igm, "뛰다");
v = v.replace(/\bSucceeded\b/igm, "성공");
v = v.replace(/\bSource\b/igm, "출처");
v = v.replace(/\bsize\b/igm, "크기");
v = v.replace(/\bVerification\b/igm, "확인");
v = v.replace(/\bServer\b/igm, "섬기는 사람");
v = v.replace(/\bProtected\b/igm, "보호 된");
v = v.replace(/\bVMs\b/igm, "VM");
v = v.replace(/\bMax duration\b/igm, "최대 기간");
v = v.replace(/\bQuota\b/igm, "몫");
v = v.replace(/\bUsed\b/igm, "익숙한");
v = v.replace(/\bCreate\b/igm, "몹시 떠들어 대다");
v = v.replace(/\bLast\b/igm, "마지막");
v = v.replace(/\bSearch\b/igm, "수색");
v = v.replace(/\bOwner\b/igm, "소유자");
v = v.replace(/\bDatabase\b/igm, "데이터 베이스");
v = v.replace(/\bOriginal\b/igm, "기발한");
v = v.replace(/\bAlternative\b/igm, "대안");
v = v.replace(/\bThis\b/igm, "이");
v = v.replace(/\bServer:\b/igm, "섬기는 사람:");
v = v.replace(/\bDashboard\b/igm, "계기반");
v = v.replace(/\bReports\b/igm, "보고서");
v = v.replace(/\b All Servers \b/igm, " 모든 서버");
v = v.replace(/\bBackup Server\b/igm, "백업 서버");
v = v.replace(/\bJobs\b/igm, "채용 정보");
v = v.replace(/\bStart\b/igm, "스타트");
v = v.replace(/\bStop\b/igm, "중지");
v = v.replace(/\bRetry\b/igm, "다시 해 보다");
v = v.replace(/\bName\b/igm, "이름");
v = v.replace(/\bType\b/igm, "유형");
v = v.replace(/\bPlatform\b/igm, "플랫폼");
v = v.replace(/\bDescription\b/igm, "기술");
v = v.replace(/\bCreated\b/igm, "만들어진");
v = v.replace(/\bMachines\b/igm, "기계");
v = v.replace(/\bMachine\b/igm, "기계");
v = v.replace(/\bRestore\b/igm, "복원");
v = v.replace(/\bHistory\b/igm, "역사");
v = v.replace(/\bLocation\b/igm, "위치");
v = v.replace(/\bPath\b/igm, "통로");
v = v.replace(/\bFiles\b/igm, "파일들");
v = v.replace(/\bDownload\b/igm, "다운로드");
v = v.replace(/\bItems\b/igm, "항목");
v = v.replace(/\bRequests\b/igm, "요청");
v = v.replace(/\bConfiguration\b/igm, "구성");
v = v.replace(/\bRefresh\b/igm, "새롭게 하다");
v = v.replace(/\bSummary\b/igm, "개요");
v = v.replace(/\bJobs\b/igm, "채용 정보");
v = v.replace(/\bMachines\b/igm, "기계");
v = v.replace(/\bTemplates\b/igm, "템플릿");
v = v.replace(/\bData\b/igm, "데이터");
v = v.replace(/\bWarning\b/igm, "경고");
v = v.replace(/\bError\b/igm, "오류");
v = v.replace(/\bStatus\b/igm, "지위");
v = v.replace(/\bBackups\b/igm, "백업");
v = v.replace(/\bBackup servers\b/igm, "백업 서버");
v = v.replace(/\bLicense\b/igm, "특허");
v = v.replace(/\bReload\b/igm, "다시로드");
v = v.replace(/\bTags\b/igm, "태그");
v = v.replace(/\band\b/igm, "과");
v = v.replace(/\bEverything\b/igm, "모두");
v = v.replace(/\bCategory\b/igm, "범주");
v = v.replace(/\bStarting\b/igm, "시작 중");
v = v.replace(/\bWorking\b/igm, "일");
v = v.replace(/\bEdit\b/igm, "편집하다");
v = v.replace(/\bActive Full\b/igm, "액티브 풀");
v = v.replace(/\bDisable\b/igm, "사용 안함");
v = v.replace(/\bObject\b/igm, "목적");
v = v.replace(/\bIn progress\b/igm, "진행 중");
v = v.replace(/\bPerformance\b/igm, "공연");
v = v.replace(/\bEnd Time\b/igm, "종료 시간");
v = v.replace(/\bList\b/igm, "명부");
v = v.replace(/\bProcessing rate\b/igm, "처리 속도");
v = v.replace(/\bProcessed size\b/igm, "처리 된 크기");
v = v.replace(/\bTotal time\b/igm, "총 시간");
v = v.replace(/\bPerformance Rate\b/igm, "성능 비율");
v = v.replace(/\bDetails\b/igm, "세부");
v = v.replace(/\bData Transferred\b/igm, "전송 된 데이터");
v = v.replace(/\bFailed\b/igm, "실패한");
v = v.replace(/\bLogout\b/igm, "로그 아웃");
v = v.replace(/\bCustomize Application\b/igm, "응용 프로그램 사용자 정의");
v = v.replace(/\bTransaction logs\b/igm, "트랜잭션 로그");
v = v.replace(/\bRequire success\b/igm, "성공을 요구하십시오");
v = v.replace(/\bExcludes\b/igm, "제외");
v = v.replace(/\bGeneral\b/igm, "일반");
v = v.replace(/\bApplications\b/igm, "응용 프로그램");
v = v.replace(/\bRequire successful application processing\b/igm, "성공적인 응용 프로그램 처리 필요");
v = v.replace(/\bIgnore application processing failures\b/igm, "응용 프로그램 처리 실패 무시");
v = v.replace(/\bTransaction logs processing\b/igm, "처리중인 트랜잭션 로그");
v = v.replace(/\btimes\b/igm, "타임스");
v = v.replace(/\bminutes\b/igm, "의사록");
v = v.replace(/\bMail\b/igm, "우편");
v = v.replace(/\bCalendar\b/igm, "달력");
v = v.replace(/\bContacts\b/igm, "콘택트 렌즈");








	
	textNode.nodeValue = v;
}


