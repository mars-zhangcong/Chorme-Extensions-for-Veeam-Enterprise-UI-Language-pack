// Veeam Enterprise Manager UI JP Language Pack
// POC版　
// 辞書データは別途エクセルファイルで生成後、handleText内にコピペ
// 辞書のアップデートはウェブ改ざん監視の仕組みを使う



window.addEventListener('load',walk(document.body));
var observer = new MutationObserver(function(mutations) {
	mutations.forEach(function(mutation) {
		walk(document.body);
	});    
});
 
// Notify me of everything!
var observerConfig = {
	attributes: true, 
	childList: true, 
	characterData: true 
};
 
// Node, config
// In this case we'll listen to all changes to body and child nodes
var targetNode = document.body;
observer.observe(targetNode, observerConfig);


function walk(node) 
{
	var ignore = { "STYLE":0, "SCRIPT":0, "NOSCRIPT":0, "IFRAME":0, "OBJECT":0 }
	// I stole this function from here:
	// http://is.gd/mwZp7E
	
	var child, next;
	
if (node.nodeName.toLowerCase() == 'input' || node.nodeName.toLowerCase() == 'textarea' || (node.classList && node.classList.contains('ace_editor'))) { return; }

	if (node.tagName in ignore) return;
	
	switch ( node.nodeType )  
	{
		case 1:  // Element
		case 9:  // Document
		case 11: // Document fragment
			child = node.firstChild;
			while ( child ) 
			{
				next = child.nextSibling;
				walk(child);
				child = next;
			}
			break;

		case 3: // Text node
			handleText(node);
			break;
	}
}



function handleText(textNode) 
{

	var v = textNode.nodeValue;

// エクセル辞書ファイルからコピペ

v = v.replace(/\bSelect virtual machines to process\b/igm, "保護対象の仮想マシンを選択");
v = v.replace(/\bCreated by\b/igm, "作成日");
v = v.replace(/\bChoose guest OS processing options available for running VMs\b/igm, "ゲストOS処理を選択してください");
v = v.replace(/\bEnable application-aware image-processing\b/igm, "アプリケーションアウェアな画像処理");
v = v.replace(/\bRun the job automatically\b/igm, "ジョブを自動的に実行");
v = v.replace(/\bDaily at this time\b/igm, "日次");
v = v.replace(/\bMonthly at\b/igm, "月次");
v = v.replace(/\bAll changes will be lost. Do you want to proceed?\b/igm, "変更が保存されていません。続けますか？");
v = v.replace(/\bSelect VM to view details\b/igm, "詳細を表示");
v = v.replace(/\bSelf-Service Backup Portal For\b/igm, "Veeamセルフサービスポータル");
v = v.replace(/\bWait before each attempt for\b/igm, "連続リトライの間隔");
v = v.replace(/\bTerminate job if it gets out of allowed backup window\b/igm, "ウィンドウ外の場合ジョブを停止");
v = v.replace(/\bLast 24 hours\b/igm, "直近24時間");
v = v.replace(/\bLast 7 days\b/igm, "直近7日間");
v = v.replace(/\bSpecify the job name, description and retention policy\b/igm, "設定項目を入力してください");
v = v.replace(/\bJob name\b/igm, "ジョブ名");
v = v.replace(/\bRetention policy\b/igm, "保管ポリシー");
v = v.replace(/\bRestore points to keep on disk\b/igm, "リストアポイント数");
v = v.replace(/\bClose Wizard\b/igm, "ウィザード");
v = v.replace(/\bVirtual Machines\b/igm, "仮想マシン");
v = v.replace(/\bAdd Objects\b/igm, "オブジェクトの追加");
v = v.replace(/\bJob Schedule\b/igm, "ジョブスケジュール");
v = v.replace(/\bBackup window\b/igm, "バックアップウィンドウ");
v = v.replace(/\bSelf-service backup portal\b/igm, "バックアップポータル");
v = v.replace(/\bhas been created successfully.\b/igm, "：ジョブが正常に保存されました");
v = v.replace(/\bInstance license support is in progress\b/igm, "ライセンスサポートが有効です");
v = v.replace(/\bAverage speed\b/igm, "平均スピード");
v = v.replace(/\bBackup Storage\b/igm, "バックアップストレージ");
v = v.replace(/\bType in\b/igm, "入力");
v = v.replace(/\bRestore Point\b/igm, "リストアポイント");
v = v.replace(/\bDatabase to restore:\b/igm, "リストアするデータベース");
v = v.replace(/\bPoint in time\b/igm, "ポイントインタイム");
v = v.replace(/\bRestore to\b/igm, "リストア先");
v = v.replace(/\bLatest Run\b/igm, "最終実行");
v = v.replace(/\bNext Run\b/igm, "次回実行");
v = v.replace(/\bFailover Plan\b/igm, "DRプラン");
v = v.replace(/\bQuick Backup\b/igm, "簡単バックアップ");
v = v.replace(/\bLast Success\b/igm, "最終");
v = v.replace(/\bPick from List\b/igm, "リストから選択");
v = v.replace(/\bAdd to\b/igm, "追加：");
v = v.replace(/\bBackup servers\b/igm, "バックアップサーバ");
v = v.replace(/\bProcessing speed\b/igm, "処理速度");
v = v.replace(/\bSource size\b/igm, "ソース容量");
v = v.replace(/\bFull backups\b/igm, "フル・バックアップ");
v = v.replace(/\bRestore points\b/igm, "リストアポイント");
v = v.replace(/\bTotal job runs\b/igm, "合計ジョブ実行数");
v = v.replace(/\bSucceeded jobs\b/igm, "成功");
v = v.replace(/\bManagement server\b/igm, "管理サーバ");
v = v.replace(/\bNever started\b/igm, "履歴なし");
v = v.replace(/\bVirtual machine\b/igm, "仮想マシン");
v = v.replace(/\bNo Filter\b/igm, "フィルタ解除");
v = v.replace(/\bApplication-Aware Processing Options\b/igm, "アプリケーション設定オプション");
v = v.replace(/\bPeriodically every\b/igm, "定期的");
v = v.replace(/\bAfter next job\b/igm, "次のジョブの直後");
v = v.replace(/\bEveryday\b/igm, "毎日");
v = v.replace(/\bOn week-days\b/igm, "平日");
v = v.replace(/\bOn these days\b/igm, "指定日");
v = v.replace(/\bhas been updated\b/igm, "の更新が完了しました。");
v = v.replace(/\bVeeam Backup Enterprise Manager\b/igm, "Veeamセルフサービスポータル");
v = v.replace(/\bWelcome\b/igm, "ようこそ");
v = v.replace(/\bPlease log in\b/igm, "ログインしてください");
v = v.replace(/\bUsername\b/igm, "ユーザ名");
v = v.replace(/\bPassword\b/igm, "パスワード");
v = v.replace(/\bRemember me\b/igm, "ログイン内容を保存");
v = v.replace(/\bLogin\b/igm, "ログイン");
v = v.replace(/\bLoading, please stand by\b/igm, "ロード中");
v = v.replace(/\bLoading\b/igm, "ロード中");
v = v.replace(/\bCreate Backup Job\b/igm, "バックアップジョブ作成");
v = v.replace(/\bJob Settings\b/igm, "基本設定");
v = v.replace(/\bDescription\b/igm, "説明");
v = v.replace(/\bNext\b/igm, "次へ");
v = v.replace(/\bCancel\b/igm, "キャンセル");
v = v.replace(/\bYes\b/igm, "はい");
v = v.replace(/\bNo\b/igm, "いいえ");
v = v.replace(/\bAdd\b/igm, "追加");
v = v.replace(/\bRemove\b/igm, "削除");
v = v.replace(/\bExclusions\b/igm, "除外");
v = v.replace(/\bUp\b/igm, "上");
v = v.replace(/\bDown\b/igm, "下");
v = v.replace(/\bName\b/igm, "VM名");
v = v.replace(/\bType\b/igm, "タイプ");
v = v.replace(/\bGuest Processing\b/igm, "ゲストOS処理");
v = v.replace(/\bEnable guest file system indexing\b/igm, "ゲストファイルのインデックス");
v = v.replace(/\bGuest OS credentials\b/igm, "ゲストOSログイン情報");
v = v.replace(/\bCredentials\b/igm, "ログイン情報");
v = v.replace(/\bCustomize Credentials\b/igm, "ログイン情報を指定");
v = v.replace(/\bSpecify the job scheduling options\b/igm, "ジョブスケジュールのオプションを選択してください");
v = v.replace(/\bAutomatic retry\b/igm, "自動リトライ");
v = v.replace(/\bRetry failed VM processing\b/igm, "エラー時のリトライ回数");
v = v.replace(/\bEmail notifications\b/igm, "メール通知");
v = v.replace(/\bSpecify recipients and settings for th job status emails:\b/igm, "メール通知の宛先");
v = v.replace(/\bEnable e-mail notifications\b/igm, "メール通知を有効にする");
v = v.replace(/\bRecipients\b/igm, "宛先");
v = v.replace(/\bSubject\b/igm, "件名");
v = v.replace(/\bNotify on success\b/igm, "成功時にメール通知");
v = v.replace(/\bNotify on warning\b/igm, "警告時にメール通知");
v = v.replace(/\bNotify on error\b/igm, "エラー時にメール通知");
v = v.replace(/\bSuppress notifications until the last retry\b/igm, "最終リトライまで通知しない");
v = v.replace(/\bBack\b/igm, "戻る");
v = v.replace(/\bFinish\b/igm, "完了");
v = v.replace(/\bSaving\b/igm, "保存中");
v = v.replace(/\bShow\b/igm, "表示");
v = v.replace(/\bAll\b/igm, "全て");
v = v.replace(/\bNone\b/igm, "なし");
v = v.replace(/\bThroughput\b/igm, "スループット");
v = v.replace(/\bJob\b/igm, "ジョブ");
v = v.replace(/\bSuccess\b/igm, "成功");
v = v.replace(/\bExport\b/igm, "エキスポート");
v = v.replace(/\bDelete\b/igm, "削除");
v = v.replace(/\bTotal\b/igm, "合計");
v = v.replace(/\bpoints\b/igm, "ポイント");
v = v.replace(/\bruns\b/igm, "実行");
v = v.replace(/\bSucceeded\b/igm, "成功");
v = v.replace(/\bSource\b/igm, "元");
v = v.replace(/\bsize\b/igm, "サイズ");
v = v.replace(/\bVerification\b/igm, "確認");
v = v.replace(/\bServer\b/igm, "サーバ");
v = v.replace(/\bProtected\b/igm, "保護対象");
v = v.replace(/\bVMs\b/igm, "仮想マシン");
v = v.replace(/\bMax duration\b/igm, "最長ジョブ");
v = v.replace(/\bQuota\b/igm, "容量");
v = v.replace(/\bUsed\b/igm, "使用");
v = v.replace(/\bCreate\b/igm, "作成");
v = v.replace(/\bLast\b/igm, "最終");
v = v.replace(/\bSearch\b/igm, "検索");
v = v.replace(/\bOwner\b/igm, "作成者");
v = v.replace(/\bDatabase\b/igm, "データベース");
v = v.replace(/\bOriginal\b/igm, "元の");
v = v.replace(/\bAlternative\b/igm, "別の");
v = v.replace(/\bThis\b/igm, "次の");
v = v.replace(/\bServer:\b/igm, "サーバ：");
v = v.replace(/\bDashboard\b/igm, "ダッシュボード");
v = v.replace(/\bReports\b/igm, "レポート");
v = v.replace(/\b All Servers \b/igm, "全てのサーバ");
v = v.replace(/\bBackup Server\b/igm, "バックアップサーバ");
v = v.replace(/\bJobs\b/igm, "ジョブ");
v = v.replace(/\bStart\b/igm, "実行");
v = v.replace(/\bStop\b/igm, "停止");
v = v.replace(/\bRetry\b/igm, "再実行");
v = v.replace(/\bName\b/igm, "タイトル");
v = v.replace(/\bType\b/igm, "タイプ");
v = v.replace(/\bPlatform\b/igm, "プラットフォーム");
v = v.replace(/\bDescription\b/igm, "説明");
v = v.replace(/\bCreated\b/igm, "作成");
v = v.replace(/\bMachines\b/igm, "マシン");
v = v.replace(/\bMachine\b/igm, "マシン");
v = v.replace(/\bRestore\b/igm, "リストア");
v = v.replace(/\bHistory\b/igm, "履歴");
v = v.replace(/\bLocation\b/igm, "格納場所");
v = v.replace(/\bPath\b/igm, "パス");
v = v.replace(/\bFiles\b/igm, "ファイル");
v = v.replace(/\bDownload\b/igm, "ダウンロード");
v = v.replace(/\bItems\b/igm, "アイテム");
v = v.replace(/\bRequests\b/igm, "リクエスト");
v = v.replace(/\bConfiguration\b/igm, "設定");
v = v.replace(/\bRefresh\b/igm, "更新");
v = v.replace(/\bSummary\b/igm, "サマリー");
v = v.replace(/\bJobs\b/igm, "ジョブ");
v = v.replace(/\bMachines\b/igm, "仮想マシン");
v = v.replace(/\bTemplates\b/igm, "テンプレート");
v = v.replace(/\bData\b/igm, "データ");
v = v.replace(/\bWarning\b/igm, "警告");
v = v.replace(/\bError\b/igm, "エラー");
v = v.replace(/\bStatus\b/igm, "ステータス");
v = v.replace(/\bBackups\b/igm, "バックアップ");
v = v.replace(/\bBackup servers\b/igm, "バックアップサーバ");
v = v.replace(/\bLicense\b/igm, "ライセンス");
v = v.replace(/\bReload\b/igm, "更新");
v = v.replace(/\bTags\b/igm, "タグ");
v = v.replace(/\band\b/igm, "と");
v = v.replace(/\bEverything\b/igm, "全て");
v = v.replace(/\bCategory\b/igm, "カテゴリ");
v = v.replace(/\bStarting\b/igm, "開始");
v = v.replace(/\bWorking\b/igm, "実行中");
v = v.replace(/\bEdit\b/igm, "編集");
v = v.replace(/\bActive Full\b/igm, "アクティブフル");
v = v.replace(/\bDisable\b/igm, "無効化");
v = v.replace(/\bObject\b/igm, "オブジェクト");
v = v.replace(/\bIn progress\b/igm, "実行中");
v = v.replace(/\bPerformance\b/igm, "パフォーマンス");
v = v.replace(/\bEnd Time\b/igm, "終了時間");
v = v.replace(/\bList\b/igm, "リスト");
v = v.replace(/\bProcessing rate\b/igm, "処理レート");
v = v.replace(/\bProcessed size\b/igm, "処理サイズ");
v = v.replace(/\bTotal time\b/igm, "合計時間");
v = v.replace(/\bPerformance Rate\b/igm, "パフォーマンスレート");
v = v.replace(/\bDetails\b/igm, "詳細");
v = v.replace(/\bData Transferred\b/igm, "転送済みデータ");
v = v.replace(/\bFailed\b/igm, "失敗");
v = v.replace(/\bLogout\b/igm, "ログアウト");
v = v.replace(/\bCustomize Application\b/igm, "アプリケーション設定");
v = v.replace(/\bTransaction logs\b/igm, "トランザクションログ");
v = v.replace(/\bRequire success\b/igm, "条件：成功");
v = v.replace(/\bExcludes\b/igm, "除外");
v = v.replace(/\bGeneral\b/igm, "全般");
v = v.replace(/\bApplications\b/igm, "アプリケーション");
v = v.replace(/\bRequire successful application processing\b/igm, "正常なアプリケーション処理を要求");
v = v.replace(/\bIgnore application processing failures\b/igm, "アプリケーション処理の失敗を無視");
v = v.replace(/\bTransaction logs processing\b/igm, "トランザクションログの処理");
v = v.replace(/\btimes\b/igm, "回");
v = v.replace(/\bminutes\b/igm, "分");
v = v.replace(/\bMail\b/igm, "メール");
v = v.replace(/\bCalendar\b/igm, "カレンダー");
v = v.replace(/\bContacts\b/igm, "連絡先");
v = v.replace(/\bDays\b/igm, "日");
v = v.replace(/\bMonths\b/igm, "月");
v = v.replace(/\bSchedule\b/igm, "スケジュール");
v = v.replace(/\bWindow\b/igm, "ウィンドウ");









	
	textNode.nodeValue = v;
}


